#!/usr/bin/env python3
"""Local PDF literature index. Python 3.9+, standard library only."""

import argparse
import hashlib
import json
import os
import re
import secrets
import sqlite3
import subprocess
import sys
import threading
import unicodedata
import webbrowser
from contextlib import contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit


STATUSES = {"未读", "粗读", "精读", "已引用"}
SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS libraries (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, path TEXT NOT NULL UNIQUE,
 last_scan TEXT
);
CREATE TABLE IF NOT EXISTS papers (
 id INTEGER PRIMARY KEY, library_id INTEGER NOT NULL REFERENCES libraries(id) ON DELETE CASCADE,
 rel_path TEXT NOT NULL, parsed_title TEXT NOT NULL, parsed_type TEXT NOT NULL,
 title_override TEXT, type_override TEXT, starred INTEGER NOT NULL DEFAULT 0,
 size INTEGER NOT NULL, mtime_ns INTEGER NOT NULL, sha256 TEXT NOT NULL,
 present INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT '未读',
 note TEXT NOT NULL DEFAULT '', needs_review INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,
 UNIQUE(library_id, rel_path)
);
CREATE INDEX IF NOT EXISTS idx_papers_hash ON papers(sha256);
CREATE TABLE IF NOT EXISTS tags (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE);
CREATE TABLE IF NOT EXISTS paper_tags (
 paper_id INTEGER NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
 tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
 PRIMARY KEY(paper_id, tag_id)
);
CREATE TABLE IF NOT EXISTS rules (
 id INTEGER PRIMARY KEY, library_id INTEGER NOT NULL REFERENCES libraries(id) ON DELETE CASCADE,
 tag TEXT NOT NULL, keywords TEXT NOT NULL
);
"""


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def parse_name(filename):
    stem = Path(filename).stem.strip()
    match = re.match(r"^\[([^\]]+)\]\s*(.*)$", stem)
    kind = match.group(1).strip().upper() if match else ""
    title = match.group(2).strip() if match else stem
    starred = title.startswith("★")
    return (title.lstrip("★").strip() or stem, kind, int(starred))


def normalized_title(title):
    return "".join(
        c for c in unicodedata.normalize("NFKC", title).casefold() if c.isalnum()
    )


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def contained(a, b):
    """Whether either canonical path contains the other."""
    a, b = os.path.normcase(os.path.realpath(a)), os.path.normcase(os.path.realpath(b))
    try:
        return os.path.commonpath((a, b)) in (a, b)
    except ValueError:  # different Windows drives
        return False


def filename_folder(rel_path):
    parts = Path(rel_path).parts
    return "/".join(parts[:-1]) if len(parts) > 1 else "根目录"


def keyword_match(text, term):
    term = term.strip().casefold()
    text = text.casefold()
    if not term:
        return False
    left = r"(?<![a-z0-9])" if re.match(r"[a-z0-9]", term[0]) else ""
    right = r"(?![a-z0-9])" if re.match(r"[a-z0-9]", term[-1]) else ""
    return re.search(left + re.escape(term) + right, text) is not None


class Catalog:
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "literature.sqlite3"
        self.scan_lock = threading.Lock()
        with self.db() as con:
            con.execute("PRAGMA journal_mode=WAL")
            con.executescript(SCHEMA)

    @contextmanager
    def db(self):
        con = sqlite3.connect(str(self.db_path), timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        try:
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def libraries(self):
        with self.db() as con:
            return [dict(r) for r in con.execute(
                """SELECT l.*, COUNT(p.id) AS total,
                   SUM(CASE WHEN p.present=1 THEN 1 ELSE 0 END) AS available
                   FROM libraries l LEFT JOIN papers p ON p.library_id=l.id
                   GROUP BY l.id ORDER BY l.name COLLATE NOCASE"""
            )]

    def add_library(self, name, path):
        name, raw_path = str(name).strip(), str(path).strip()
        if not name or len(name) > 100:
            raise ValueError("请输入不超过 100 字的文献库名称")
        if not raw_path:
            raise ValueError("请输入文献库文件夹的完整路径")
        path = Path(raw_path).expanduser()
        if not path.is_dir():
            raise ValueError("文件夹不存在，请检查路径")
        real = str(path.resolve())
        with self.db() as con:
            for row in con.execute("SELECT path FROM libraries"):
                if contained(real, row["path"]):
                    raise ValueError("此文件夹与已有文献库重叠，请选择互不包含的目录")
            cur = con.execute("INSERT INTO libraries(name,path) VALUES(?,?)", (name, real))
            return cur.lastrowid

    def rename_library(self, library_id, name):
        name = str(name).strip()
        if not name or len(name) > 100:
            raise ValueError("名称不能为空，且不能超过 100 字")
        with self.db() as con:
            cur = con.execute("UPDATE libraries SET name=? WHERE id=?", (name, library_id))
            if not cur.rowcount:
                raise ValueError("文献库不存在")

    def scan(self, library_id):
        with self.scan_lock, self.db() as con:
            lib = con.execute("SELECT * FROM libraries WHERE id=?", (library_id,)).fetchone()
            if not lib:
                raise ValueError("文献库不存在")
            root = Path(lib["path"])
            if not root.is_dir():
                raise ValueError("文献库目录暂时不可访问，已保留现有索引")
            errors, found = [], {}

            def walk_error(err):
                errors.append(str(err))

            for base, dirs, files in os.walk(root, onerror=walk_error, followlinks=False):
                dirs[:] = [d for d in dirs if not (Path(base) / d).is_symlink()]
                for name in files:
                    if not name.lower().endswith(".pdf"):
                        continue
                    path = Path(base) / name
                    if path.is_symlink():
                        continue
                    try:
                        stat = path.stat()
                        rel = str(path.relative_to(root))
                        found[rel] = (path, stat.st_size, stat.st_mtime_ns)
                    except OSError as err:
                        errors.append(str(err))
            old = {
                row["rel_path"]: row
                for row in con.execute("SELECT * FROM papers WHERE library_id=?", (library_id,))
            }
            added = moved = changed = 0
            for rel, (path, size, mtime) in found.items():
                previous = old.get(rel)
                try:
                    digest = (previous["sha256"]
                              if previous and previous["size"] == size
                              and previous["mtime_ns"] == mtime and previous["sha256"]
                              else sha256(path))
                except OSError as err:
                    errors.append(str(err))
                    continue
                title, kind, starred = parse_name(path.name)
                if previous:
                    if (previous["size"], previous["mtime_ns"], previous["present"]) != (size, mtime, 1):
                        changed += 1
                    con.execute(
                        """UPDATE papers SET parsed_title=?,parsed_type=?,starred=?,
                           size=?,mtime_ns=?,sha256=?,present=1,
                           needs_review=CASE WHEN sha256<>? THEN 1 ELSE needs_review END
                           WHERE id=?""",
                        (title, kind, starred, size, mtime, digest, digest, previous["id"]),
                    )
                else:
                    # Preserve notes when a unique old PDF was renamed or moved within this library.
                    candidates = [p for p in old.values()
                                  if p["rel_path"] not in found and p["sha256"] == digest]
                    if len(candidates) == 1:
                        p = candidates[0]
                        con.execute(
                            """UPDATE papers SET rel_path=?,parsed_title=?,parsed_type=?,
                               starred=?,size=?,mtime_ns=?,sha256=?,present=1 WHERE id=?""",
                            (rel, title, kind, starred, size, mtime, digest, p["id"]),
                        )
                        del old[p["rel_path"]]
                        moved += 1
                    else:
                        con.execute(
                            """INSERT INTO papers(library_id,rel_path,parsed_title,parsed_type,
                               starred,size,mtime_ns,sha256,created_at)
                               VALUES(?,?,?,?,?,?,?,?,?)""",
                            (library_id, rel, title, kind, starred, size, mtime, digest, now()),
                        )
                        added += 1
            # A partial/failed traversal must never mark unseen papers missing.
            if not errors:
                con.execute("UPDATE papers SET present=0 WHERE library_id=?", (library_id,))
                for rel in found:
                    con.execute(
                        "UPDATE papers SET present=1 WHERE library_id=? AND rel_path=?",
                        (library_id, rel),
                    )
            con.execute("UPDATE libraries SET last_scan=? WHERE id=?", (now(), library_id))
            return {"added": added, "moved": moved, "updated": changed,
                    "files": len(found), "errors": errors[:10]}

    def rules(self):
        with self.db() as con:
            return [dict(row) for row in con.execute(
                "SELECT * FROM rules ORDER BY library_id, tag COLLATE NOCASE"
            )]

    def add_rule(self, library_id, tag, keywords):
        tag = str(tag).strip()
        terms = [v.strip() for v in re.split(r"[,，\n;；]+", str(keywords)) if v.strip()]
        if not tag or len(tag) > 80 or not terms or len(terms) > 40:
            raise ValueError("填写标签及 1–40 个关键词，用逗号分隔")
        with self.db() as con:
            if not con.execute("SELECT 1 FROM libraries WHERE id=?", (library_id,)).fetchone():
                raise ValueError("文献库不存在")
            con.execute("INSERT INTO rules(library_id,tag,keywords) VALUES(?,?,?)",
                        (library_id, tag, ", ".join(terms)))

    def delete_rule(self, rule_id):
        with self.db() as con:
            con.execute("DELETE FROM rules WHERE id=?", (rule_id,))

    def all_papers(self):
        with self.db() as con:
            rows = [dict(r) for r in con.execute(
                """SELECT p.*, l.name AS library_name, l.path AS library_path
                   FROM papers p JOIN libraries l ON l.id=p.library_id
                   ORDER BY p.id DESC"""
            )]
            tags = {}
            for item in con.execute(
                """SELECT pt.paper_id,t.name FROM paper_tags pt
                   JOIN tags t ON t.id=pt.tag_id ORDER BY t.name COLLATE NOCASE"""
            ):
                tags.setdefault(item["paper_id"], []).append(item["name"])
        rules = self.rules()
        folder_labels = {}
        for row in rows:
            parts = Path(row["rel_path"]).parts
            if len(parts) > 1:
                folder_labels.setdefault(row["library_id"], set()).add(parts[0])
        for row in rows:
            row["title"] = row["title_override"] or row["parsed_title"]
            row["type"] = row["type_override"] or row["parsed_type"]
            row["folder"] = filename_folder(row["rel_path"])
            row["tags"] = tags.get(row["id"], [])
            from_rules = [
                rule["tag"] for rule in rules
                if rule["library_id"] == row["library_id"]
                and rule["tag"] not in row["tags"]
                and any(keyword_match(row["title"], kw)
                        for kw in rule["keywords"].split(","))
            ]
            from_folders = [
                folder for folder in sorted(folder_labels.get(row["library_id"], set()))
                if folder not in row["tags"] and folder != row["folder"].split("/")[0]
                and keyword_match(row["title"], folder)
            ]
            row["suggestions"] = list(dict.fromkeys(from_rules + from_folders))
        return rows

    def search(self, query="", library_id=0, kind="", status="", tag="", offset=0):
        words = re.findall(r'"([^"]+)"|(\S+)', query.strip())
        tokens = [(quoted or unquoted).casefold() for quoted, unquoted in words]
        matches = []
        for row in self.all_papers():
            if library_id and row["library_id"] != library_id:
                continue
            if kind and row["type"] != kind:
                continue
            if status and row["status"] != status:
                continue
            if tag and tag.casefold() not in {t.casefold() for t in row["tags"]}:
                continue
            fields = {
                "标题": row["title"], "标签": " ".join(row["tags"]),
                "笔记": row["note"], "文件夹": row["folder"],
                "建议标签": " ".join(row["suggestions"]),
            }
            hits = [
                label for label, value in fields.items()
                if tokens and any(word in value.casefold() for word in tokens)
            ]
            corpus = " ".join(fields.values()).casefold()
            if all(word in corpus for word in tokens):
                row["hits"] = hits
                matches.append(row)
        # Favor title and explicit notes, then show newer additions first.
        matches.sort(key=lambda row: (
            -int("标题" in row["hits"]), -int("笔记" in row["hits"]), -row["id"]
        ))
        return {"total": len(matches), "papers": matches[offset:offset + 150]}

    def paper(self, paper_id):
        for paper in self.all_papers():
            if paper["id"] == paper_id:
                return paper
        raise ValueError("文献不存在")

    def save_paper(self, paper_id, payload):
        tags = payload.get("tags", [])
        if not isinstance(tags, list) or len(tags) > 30:
            raise ValueError("标签应为不超过 30 项的列表")
        tags = list(dict.fromkeys(str(t).strip() for t in tags if str(t).strip()))
        if any(len(t) > 80 for t in tags):
            raise ValueError("单个标签不能超过 80 字")
        note = str(payload.get("note", ""))
        title = str(payload.get("title", "")).strip()
        kind = str(payload.get("type", "")).strip().upper()
        status = str(payload.get("status", "未读"))
        if status not in STATUSES or len(note) > 20000 or len(title) > 600 or len(kind) > 8:
            raise ValueError("标题、类型、状态或笔记无效")
        with self.db() as con:
            if not con.execute("SELECT 1 FROM papers WHERE id=?", (paper_id,)).fetchone():
                raise ValueError("文献不存在")
            con.execute(
                """UPDATE papers SET title_override=?,type_override=?,status=?,note=?,
                   needs_review=0 WHERE id=?""",
                (title or None, kind or None, status, note, paper_id),
            )
            con.execute("DELETE FROM paper_tags WHERE paper_id=?", (paper_id,))
            for tag in tags:
                con.execute("INSERT OR IGNORE INTO tags(name) VALUES(?)", (tag,))
                tag_id = con.execute(
                    "SELECT id FROM tags WHERE name=? COLLATE NOCASE", (tag,)
                ).fetchone()["id"]
                con.execute("INSERT INTO paper_tags(paper_id,tag_id) VALUES(?,?)", (paper_id, tag_id))

    def duplicates(self):
        papers = [p for p in self.all_papers() if p["present"]]
        by_title, by_hash, groups, seen = {}, {}, [], set()
        for p in papers:
            by_title.setdefault(normalized_title(p["title"]), []).append(p)
            by_hash.setdefault(p["sha256"], []).append(p)
        for group in by_title.values():
            if len(group) > 1 and len(group[0]["title"]) > 6:
                ids = frozenset(p["id"] for p in group)
                seen.add(ids)
                groups.append({"kind": "文件完全相同" if len({p["sha256"] for p in group}) == 1
                               else "标题相同，文件可能不同", "papers": group})
        for group in by_hash.values():
            ids = frozenset(p["id"] for p in group)
            if len(group) > 1 and ids not in seen:
                groups.append({"kind": "文件完全相同", "papers": group})
        return groups

    def open_paper(self, paper_id):
        with self.db() as con:
            row = con.execute(
                """SELECT p.rel_path,p.present,l.path FROM papers p JOIN libraries l
                   ON l.id=p.library_id WHERE p.id=?""", (paper_id,)
            ).fetchone()
        if not row or not row["present"]:
            raise ValueError("文件已不在文献库中")
        root = Path(row["path"]).resolve()
        path = (root / row["rel_path"]).resolve()
        if not contained_only(root, path):
            raise ValueError("文件路径不在文献库内")
        if not path.is_file():
            raise ValueError("文件不存在，请重新扫描")
        if sys.platform == "win32":
            os.startfile(str(path))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])


def contained_only(root, path):
    try:
        root = os.path.normcase(str(root))
        path = os.path.normcase(str(path))
        return os.path.commonpath((root, path)) == root
    except ValueError:
        return False


HTML = r"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>LiteratureShelf · 文献索引</title>
<style>
:root{font-family:system-ui,"Microsoft YaHei",sans-serif;color:#233044;background:#f3f6f8}
*{box-sizing:border-box}body{margin:0}button,input,select,textarea{font:inherit}
button{cursor:pointer;border:1px solid #ccd7df;background:white;border-radius:8px;padding:8px 12px;color:#25445a}
button:hover{border-color:#397b9e;background:#f1f8fa}.primary{color:white;background:#176a80;border-color:#176a80}
.primary:hover{background:#12566a;color:white}.quiet{border:0;background:none;padding:4px 7px}
header{background:#102d40;color:white;padding:21px max(20px,calc((100vw - 1180px)/2))}
header h1{margin:0;font-size:24px;letter-spacing:.3px}header p{margin:6px 0 0;color:#b9d5dd;font-size:13px}
main{max-width:1180px;padding:22px 18px 70px;margin:auto}
.panel{background:white;border:1px solid #dce6eb;border-radius:13px;padding:18px;margin-bottom:16px;box-shadow:0 3px 20px #1d334108}
.flex{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.grow{flex:1}
input,select,textarea{border:1px solid #c8d5dd;border-radius:8px;padding:9px;background:white;color:#213747}
input:focus,textarea:focus,select:focus{outline:2px solid #a2d8e0}
#query{min-width:250px;flex:1;font-size:16px;padding:11px}select{max-width:220px}
.sub{color:#657986;font-size:13px}.error{color:#a53434}.ok{color:#156c51}
.tabs{display:flex;gap:9px;margin-bottom:14px}.tabs button.active{background:#dceff0;border-color:#85b8c3;font-weight:650}
.paper{padding:16px 4px;border-bottom:1px solid #e3e9ed}.paper:last-child{border-bottom:0}
.paper h3{font-size:16px;line-height:1.4;margin:3px 0 8px;cursor:pointer;color:#164c67}.paper h3:hover{text-decoration:underline}
.chip{display:inline-block;margin:3px 5px 3px 0;padding:3px 8px;border-radius:14px;background:#e6f0f3;color:#255266;font-size:12px}
.chip.folder{background:#f2eadb;color:#705736}.chip.suggest{background:#f4eef9;color:#694e82}
.meta{font-size:12px;color:#6b7d87;overflow-wrap:anywhere}.note{font-size:13px;color:#435c68;margin:7px 0}
.row{display:flex;justify-content:space-between;gap:14px}.row>*:first-child{min-width:0}
.wrap{overflow-wrap:anywhere}.muted{opacity:.6}.hint{margin-top:8px;color:#4d6d7d;font-size:12px}
.formgrid{display:grid;grid-template-columns:180px 1fr auto;gap:8px;align-items:center}
.rulegrid{display:grid;grid-template-columns:180px 1fr 1fr auto;gap:8px}
.libline,.ruleline{padding:9px 0;border-bottom:1px solid #edf1f3}
dialog{width:min(720px,calc(100vw - 24px));max-height:90vh;border:1px solid #bed0d8;border-radius:13px;padding:24px;box-shadow:0 20px 80px #0004}
dialog::backdrop{background:#102d4088}dialog input,dialog textarea{width:100%;margin:5px 0 14px}
dialog textarea{height:145px;resize:vertical}.close{float:right}
.small{font-size:12px}.footer{margin-top:18px;text-align:center}
@media(max-width:650px){.formgrid,.rulegrid{grid-template-columns:1fr}.row{display:block}}
</style></head><body>
<header><h1>LiteratureShelf</h1><p>本地文献索引 · 文件留在原处 · 可为一篇文章添加多个标签</p></header>
<main>
<section class="panel"><div class="flex">
<select id="library" title="选择文献库"></select>
<button onclick="showLibraries()">管理文献库</button>
<button onclick="scanSelected()">扫描更新</button><span class="sub" id="scanInfo"></span>
</div></section>
<section class="panel"><div class="flex"><input id="query" placeholder='搜标题、标签、笔记、文件夹；多个词须同时出现，"引号"匹配短语'>
<button class="primary" onclick="loadPapers()">搜索</button></div>
<div class="flex" style="margin-top:12px"><select id="kind"><option value="">全部类型</option>
<option>A</option><option>R</option><option>B</option><option>P</option></select>
<select id="status"><option value="">全部进度</option><option>未读</option><option>粗读</option><option>精读</option><option>已引用</option></select>
<select id="tag"><option value="">全部标签</option></select>
<span class="sub" id="count"></span></div></section>
<nav class="tabs"><button id="tabPapers" class="active" onclick="showTab('papers')">文献</button>
<button id="tabDuplicates" onclick="showTab('duplicates')">重复候选</button>
<button id="tabRules" onclick="showTab('rules')">分类规则</button></nav>
<section class="panel" id="papersPane"><div id="papers"></div>
<div class="footer"><button id="more" onclick="morePapers()" hidden>加载更多</button></div></section>
<section class="panel" id="duplicatesPane" hidden><p class="sub">只提示候选，不删除任何文件。相同标题可能是不同版本，请打开 PDF 核对。</p><div id="duplicates"></div></section>
<section class="panel" id="rulesPane" hidden><p class="sub">按标题关键词推荐标签。建议须在文献详情中确认；规则只作用于选定文献库。</p>
<div class="rulegrid"><select id="ruleLibrary"></select><input id="ruleTag" placeholder="建议标签，如 ADRN/MES">
<input id="ruleWords" placeholder="关键词用逗号分隔，如 adrenergic, mesenchymal"><button onclick="addRule()">添加规则</button></div>
<div id="rules"></div></section>
<section class="panel" id="librariesPane" hidden>
<div class="flex"><h2 class="grow" style="margin:0">文献库</h2><button onclick="showLibraries()">收起</button></div>
<p class="sub">粘贴文件夹的完整路径。保存后会索引其中的 PDF 和子文件夹；路径相互不能包含。</p>
<div class="formgrid"><input id="libName" placeholder="名称，如 NB"><input id="libPath" placeholder="D:\project\NB\ARTICLE"><button class="primary" onclick="addLibrary()">添加</button></div>
<div id="libraries"></div></section>
<p id="message" class="sub" role="status"></p>
</main>
<dialog id="editor"><button class="quiet close" onclick="document.querySelector('#editor').close()">✕</button>
<h2 style="margin-top:0">文献详情</h2><div id="detailPath" class="sub wrap"></div>
<p id="reviewWarning" class="error" hidden>同一路径的 PDF 内容发生变化，请核对原有笔记和标签是否仍适用。</p>
<label>标题<input id="editTitle"></label>
<div class="flex"><label>类型<br><input id="editType" style="width:80px" placeholder="A/R/B/P"></label>
<label>阅读状态<br><select id="editStatus"><option>未读</option><option>粗读</option><option>精读</option><option>已引用</option></select></label></div>
<label>标签（用逗号隔开）<input id="editTags" placeholder="一篇文献可以有多个标签"></label>
<div id="suggestions" class="sub"></div>
<label>笔记<textarea id="editNote" placeholder="一句话写下：这篇文章解决了什么问题、可用在哪"></textarea></label>
<div class="flex"><button class="primary" onclick="savePaper()">保存</button><button onclick="openCurrent()">打开 PDF</button>
<span id="editMessage" class="sub"></span></div></dialog>
<script>
const TOKEN=__TOKEN__;
let libraries=[], current=null, items=[], offset=0, active='papers';
const $=s=>document.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(url,method='GET',body){
 const res=await fetch(url,{method,headers:{'Content-Type':'application/json','X-Library-Token':TOKEN},body:body===undefined?undefined:JSON.stringify(body)});
 let data=await res.json();if(!res.ok)throw Error(data.error||'请求失败');return data;
}
function message(s,err=false){$('#message').textContent=s;$('#message').className=err?'error':'ok'}
function inform(err){message(err.message||String(err),true)}
function opts(target,options,value){target.innerHTML=options.map(([key,label])=>`<option value="${esc(key)}">${esc(label)}</option>`).join('');
 target.value=options.some(([key])=>String(key)===String(value))?String(value):String(options[0]?.[0]??'');}
async function refreshLibraries(){
 libraries=await api('/api/libraries');
 const selected=$('#library').value;
 opts($('#library'),[['','全部文献库'],...libraries.map(l=>[l.id,l.name])],selected);
 opts($('#ruleLibrary'),libraries.map(l=>[l.id,l.name]),$('#ruleLibrary').value);
 $('#libraries').innerHTML=libraries.map(l=>`<div class="libline"><strong>${esc(l.name)}</strong> · ${l.available||0} 篇
 <button class="quiet" onclick="renameLibrary(${l.id})">重命名</button>
 <div class="meta">${esc(l.path)} · 上次扫描：${esc(l.last_scan||'尚未扫描')}</div></div>`).join('')||'<p class="sub">添加第一个文献库后开始使用。</p>';
 const lib=libraries.find(l=>String(l.id)===$('#library').value);
 $('#scanInfo').textContent=lib?.last_scan?'上次扫描 '+lib.last_scan.slice(0,19).replace('T',' ')+' UTC':'';
}
async function addLibrary(){
 try{const id=(await api('/api/libraries','POST',{name:$('#libName').value,path:$('#libPath').value})).id;
 $('#libName').value='';$('#libPath').value='';await refreshLibraries();$('#library').value=String(id);
 message('文献库已添加，正在扫描……');await scanSelected();}
 catch(e){inform(e)}
}
async function renameLibrary(id){
 const lib=libraries.find(l=>l.id===id);const name=prompt('新的文献库名称（原文件夹路径不变）',lib.name);
 if(name===null)return;
 try{await api('/api/libraries/'+id,'PATCH',{name});await refreshLibraries();message('名称已更新')}catch(e){inform(e)}
}
function showLibraries(){const el=$('#librariesPane');el.hidden=!el.hidden}
async function scanSelected(){
 const id=$('#library').value;const selected=id?[Number(id)]:libraries.map(l=>l.id);
 if(!selected.length){message('请先添加文献库',true);return}
 message('正在扫描，请稍候……');
 try{let results=[];for(const n of selected)results.push(await api('/api/libraries/'+n+'/scan','POST',{}));
 await refreshLibraries();await loadPapers();
 const errors=results.flatMap(r=>r.errors);
 message(`扫描完成：新增 ${results.reduce((n,r)=>n+r.added,0)}，移动/改名 ${results.reduce((n,r)=>n+r.moved,0)}，读取错误 ${errors.length}${errors.length?'（'+errors[0]+'）':''}`,!!errors.length);
 }catch(e){inform(e)}
}
function showTab(name){active=name;
 for(const key of ['papers','duplicates','rules']){$('#'+key+'Pane').hidden=name!==key;
 $('#tab'+key[0].toUpperCase()+key.slice(1)).classList.toggle('active',name===key)}
 if(name==='duplicates')loadDuplicates();if(name==='rules')loadRules();
}
function params(){const p=new URLSearchParams({q:$('#query').value,library:$('#library').value,
 type:$('#kind').value,status:$('#status').value,tag:$('#tag').value,offset});return p}
async function loadPapers(reset=true){
 if(reset)offset=0;
 try{let data=await api('/api/papers?'+params());
 if(reset)items=[];items.push(...data.papers);renderPapers();
 $('#count').textContent=`共 ${data.total} 篇（当前显示 ${items.length} 篇）`;
 $('#more').hidden=items.length>=data.total;await loadTagOptions();
 }catch(e){inform(e)}
}
function morePapers(){offset=items.length;loadPapers(false)}
async function loadTagOptions(){const selected=$('#tag').value;const tags=await api('/api/tags');
 opts($('#tag'),[['','全部标签'],...tags.map(t=>[t,t])],selected)}
function paperHtml(p){
 const tagHtml=p.tags.map(t=>`<span class="chip">${esc(t)}</span>`).join('');
 const suggest=p.suggestions.slice(0,5).map(t=>`<span class="chip suggest">建议 · ${esc(t)}</span>`).join('');
 return `<article class="paper ${p.present?'':'muted'}"><div class="row"><div>
 <h3 onclick="editPaper(${p.id})">${p.starred?'★ ':''}${esc(p.title)}</h3>
 <div><span class="chip">${esc(p.type||'未标类型')}</span><span class="chip">${esc(p.status)}</span>
 <span class="chip folder">${esc(p.folder)}</span>${tagHtml}${suggest}</div>
 <div class="meta">${esc(p.library_name)} · ${esc(p.rel_path)} ${p.present?'':'· 文件未找到'}</div>
 ${p.needs_review?'<div class="error small">PDF 内容变更，请核对笔记</div>':''}
 ${p.note?`<div class="note">${esc(p.note.slice(0,180))}</div>`:''}
 ${p.hits?.length?`<div class="hint">命中：${esc(p.hits.join('、'))}</div>`:''}</div>
 <button onclick="editPaper(${p.id})">查看</button></div></article>`;
}
function renderPapers(){$('#papers').innerHTML=items.map(paperHtml).join('')||'<p class="sub">没有匹配的文献。可换个关键词，或检查是否已扫描文献库。</p>'}
async function editPaper(id){
 try{current=await api('/api/papers/'+id)}catch(e){return inform(e)}
 $('#detailPath').textContent=current.library_path+' / '+current.rel_path;
 $('#reviewWarning').hidden=!current.needs_review;
 $('#editTitle').value=current.title;$('#editType').value=current.type;
 $('#editStatus').value=current.status;$('#editTags').value=current.tags.join(', ');
 $('#editNote').value=current.note;$('#editMessage').textContent='';
 $('#suggestions').innerHTML=current.suggestions.length?'推荐标签：'+current.suggestions.map(t=>
 `<button class="quiet" data-addtag="${esc(t)}">＋${esc(t)}</button>`).join(''):'';
 $('#suggestions').querySelectorAll('[data-addtag]').forEach(btn=>
   btn.addEventListener('click',()=>appendTag(btn.dataset.addtag)));
 $('#editor').showModal();
}
function appendTag(tag){let tags=$('#editTags').value.split(/[,，]/).map(s=>s.trim()).filter(Boolean);
 if(!tags.some(t=>t.toLowerCase()===tag.toLowerCase()))tags.push(tag);$('#editTags').value=tags.join(', ')}
async function savePaper(){
 try{await api('/api/papers/'+current.id,'PATCH',{
 title:$('#editTitle').value,type:$('#editType').value,status:$('#editStatus').value,
 tags:$('#editTags').value.split(/[,，]/).map(s=>s.trim()).filter(Boolean),note:$('#editNote').value});
 $('#editor').close();await loadPapers();message('已保存文献笔记和标签')}
 catch(e){$('#editMessage').textContent=e.message}
}
async function openCurrent(){try{await api('/api/papers/'+current.id+'/open','POST',{})}catch(e){$('#editMessage').textContent=e.message}}
async function loadDuplicates(){
 try{const groups=await api('/api/duplicates');
 $('#duplicates').innerHTML=groups.map(g=>`<div class="paper"><strong>${esc(g.kind)}</strong>
 ${g.papers.map(p=>`<div class="meta" style="margin-top:8px">${esc(p.title)}<br>${esc(p.library_name)} · ${esc(p.rel_path)}
 <button class="quiet" onclick="editPaper(${p.id})">查看 / 打开</button></div>`).join('')}</div>`).join('')||'<p class="sub">尚未发现重复候选。</p>';
 }catch(e){inform(e)}
}
async function loadRules(){
 try{const rules=await api('/api/rules');
 $('#rules').innerHTML=rules.map(r=>`<div class="ruleline"><strong>${esc(r.tag)}</strong>
 <span class="sub"> · ${esc(libraries.find(l=>l.id===r.library_id)?.name||'')} · ${esc(r.keywords)}</span>
 <button class="quiet" onclick="deleteRule(${r.id})">删除规则</button></div>`).join('')||'<p class="sub">暂无规则。例如为 NB 库添加标签 ADRN/MES，关键词 adrenergic, mesenchymal, noradrenergic。</p>';
 }catch(e){inform(e)}
}
async function addRule(){
 try{await api('/api/rules','POST',{library_id:Number($('#ruleLibrary').value),tag:$('#ruleTag').value,keywords:$('#ruleWords').value});
 $('#ruleTag').value='';$('#ruleWords').value='';await loadRules();await loadPapers();message('规则已添加')}
 catch(e){inform(e)}
}
async function deleteRule(id){try{await api('/api/rules/'+id,'DELETE',{});await loadRules();message('规则已删除')}catch(e){inform(e)}}
for(const id of ['library','kind','status','tag'])$('#'+id).addEventListener('change',()=>loadPapers());
$('#query').addEventListener('keydown',e=>{if(e.key==='Enter')loadPapers()});
(async()=>{try{await refreshLibraries();await loadPapers()}catch(e){inform(e)}})();
</script></body></html>"""


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, catalog):
        super().__init__(address, Handler)
        self.catalog = catalog
        self.token = secrets.token_urlsafe(30)


class Handler(BaseHTTPRequestHandler):
    def reply(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def input(self):
        if self.headers.get("X-Library-Token") != self.server.token:
            raise PermissionError("请求未通过本地验证，请刷新页面")
        size = int(self.headers.get("Content-Length", "0"))
        if size < 0 or size > 100000:
            raise ValueError("请求过大")
        return json.loads(self.rfile.read(size) or b"{}")

    def handle_api(self):
        url = urlsplit(self.path)
        route = url.path
        q = parse_qs(url.query)
        cat = self.server.catalog
        parts = route.strip("/").split("/")
        if self.command == "GET":
            if route == "/api/libraries":
                return self.reply(cat.libraries())
            if route == "/api/tags":
                with cat.db() as con:
                    return self.reply([r["name"] for r in con.execute(
                        "SELECT name FROM tags ORDER BY name COLLATE NOCASE"
                    )])
            if route == "/api/rules":
                return self.reply(cat.rules())
            if route == "/api/papers":
                return self.reply(cat.search(
                    q.get("q", [""])[0], int(q.get("library", ["0"])[0] or 0),
                    q.get("type", [""])[0], q.get("status", [""])[0],
                    q.get("tag", [""])[0], max(0, int(q.get("offset", ["0"])[0] or 0))
                ))
            if route == "/api/duplicates":
                return self.reply(cat.duplicates())
            if len(parts) == 3 and parts[:2] == ["api", "papers"]:
                return self.reply(cat.paper(int(parts[2])))
        else:
            data = self.input()
            if self.command == "POST" and route == "/api/libraries":
                return self.reply({"id": cat.add_library(data.get("name", ""), data.get("path", ""))})
            if self.command == "POST" and route == "/api/rules":
                cat.add_rule(data.get("library_id"), data.get("tag", ""), data.get("keywords", ""))
                return self.reply({"ok": True})
            if len(parts) == 3 and parts[0] == "api":
                item_id = int(parts[2])
                if parts[1] == "libraries" and self.command == "PATCH":
                    cat.rename_library(item_id, data.get("name", ""))
                    return self.reply({"ok": True})
                if parts[1] == "papers" and self.command == "PATCH":
                    cat.save_paper(item_id, data)
                    return self.reply({"ok": True})
                if parts[1] == "rules" and self.command == "DELETE":
                    cat.delete_rule(item_id)
                    return self.reply({"ok": True})
            if len(parts) == 4 and parts[:2] == ["api", "libraries"] and parts[3] == "scan" and self.command == "POST":
                return self.reply(cat.scan(int(parts[2])))
            if len(parts) == 4 and parts[:2] == ["api", "papers"] and parts[3] == "open" and self.command == "POST":
                cat.open_paper(int(parts[2]))
                return self.reply({"ok": True})
        return self.reply({"error": "地址不存在"}, 404)

    def do_GET(self):
        try:
            if self.path == "/":
                body = HTML.replace("__TOKEN__", json.dumps(self.server.token)).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Security-Policy",
                                 "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'")
                self.end_headers()
                self.wfile.write(body)
            else:
                self.handle_api()
        except (ValueError, PermissionError, sqlite3.Error) as err:
            self.reply({"error": str(err)}, 400)
        except Exception as err:
            self.reply({"error": "操作失败：" + str(err)}, 500)

    def do_POST(self):
        self.mutate()

    def do_PATCH(self):
        self.mutate()

    def do_DELETE(self):
        self.mutate()

    def mutate(self):
        try:
            self.handle_api()
        except (ValueError, PermissionError, sqlite3.Error) as err:
            self.reply({"error": str(err)}, 400)
        except Exception as err:
            self.reply({"error": "操作失败：" + str(err)}, 500)

    def log_message(self, fmt, *args):
        if not self.path.startswith("/api/"):
            return
        super().log_message(fmt, *args)


def default_data_dir():
    if sys.platform == "win32":
        return Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "LiteratureShelf"
    return Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local/share"))) / "LiteratureShelf"


def main():
    parser = argparse.ArgumentParser(description="本地 PDF 文献检索与管理")
    parser.add_argument("--data-dir", type=Path, default=default_data_dir())
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--interval", type=int, default=120,
                        help="后台自动扫描间隔（秒）；0 表示仅手动扫描")
    args = parser.parse_args()
    catalog = Catalog(args.data_dir)
    server = Server(("127.0.0.1", args.port), catalog)
    url = "http://127.0.0.1:" + str(server.server_port) + "/"
    print("LiteratureShelf: " + url, flush=True)
    print("索引位置: " + str(catalog.db_path), flush=True)
    print("按 Ctrl+C 退出。", flush=True)
    stop = threading.Event()

    def auto_scan():
        # First run on startup; then index completed PDF downloads periodically.
        while not stop.is_set():
            for lib in catalog.libraries():
                if stop.is_set():
                    break
                try:
                    catalog.scan(lib["id"])
                except Exception as err:
                    print("自动扫描失败: " + str(err), file=sys.stderr)
            if not args.interval or stop.wait(args.interval):
                break

    if args.interval:
        threading.Thread(target=auto_scan, daemon=True).start()
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已退出。")
    finally:
        stop.set()
        server.server_close()


if __name__ == "__main__":
    main()
