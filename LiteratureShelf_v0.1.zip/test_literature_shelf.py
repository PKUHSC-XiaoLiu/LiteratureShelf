import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from LiteratureShelf import Catalog, Server


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.nb = self.base / "NB"
        self.other = self.base / "Other"
        self.nb.mkdir()
        self.other.mkdir()
        self.cat = Catalog(self.base / "data")

    def pdf(self, root, rel, content=b"%PDF-1.4\nfirst"):
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return path

    def test_scan_search_duplicates_notes_and_rename(self):
        nb_id = self.cat.add_library("NB", self.nb)
        second_id = self.cat.add_library("Other", self.other)
        self.pdf(self.nb, "ADRN&MES/[A]Mesenchymal cells escape ALK inhibitors.pdf")
        with self.assertRaisesRegex(ValueError, "重叠"):
            self.cat.add_library("nested", self.nb / "ADRN&MES")
        self.pdf(self.other, "[A]Mesenchymal cells escape ALK inhibitors.pdf")
        self.cat.scan(nb_id)
        self.cat.scan(second_id)
        self.assertEqual(self.cat.search("mesenchymal alk")["total"], 2)
        self.assertEqual(self.cat.search("ALK", nb_id)["total"], 1)
        paper = self.cat.search("ALK", nb_id)["papers"][0]
        self.assertEqual(paper["folder"], "ADRN&MES")
        self.assertEqual(paper["type"], "A")
        self.assertEqual(len(self.cat.duplicates()), 1)
        self.assertEqual(self.cat.duplicates()[0]["kind"], "文件完全相同")
        self.cat.save_paper(paper["id"], {
            "title": paper["title"], "type": "A", "status": "精读",
            "tags": ["ADRN/MES", "耐药"], "note": "ALK 抑制剂耐药的细胞状态",
        })
        self.assertEqual(self.cat.search("耐药 ALK")["total"], 1)
        self.assertEqual(self.cat.search("", tag="耐药")["total"], 1)
        old = self.nb / paper["rel_path"]
        renamed = old.with_name("[A]Mesenchymal cells escape ALK inhibitors v2.pdf")
        old.rename(renamed)
        result = self.cat.scan(nb_id)
        self.assertEqual(result["moved"], 1)
        updated = self.cat.paper(paper["id"])
        self.assertEqual(updated["status"], "精读")
        self.assertIn("耐药", updated["tags"])
        self.assertEqual(updated["present"], 1)
        renamed.unlink()
        self.cat.scan(nb_id)
        self.assertEqual(self.cat.paper(paper["id"])["present"], 0)

    def test_changed_pdf_flag_and_suggested_tags(self):
        library_id = self.cat.add_library("NB", self.nb)
        path = self.pdf(self.nb, "[R]SP100 and PML nuclear bodies.pdf")
        self.cat.scan(library_id)
        self.cat.add_rule(library_id, "PML-NBs", "PML, nuclear bodies")
        paper = self.cat.search("SP100")["papers"][0]
        self.assertEqual(paper["type"], "R")
        self.assertIn("PML-NBs", paper["suggestions"])
        path.write_bytes(b"%PDF-1.4\nsecond")
        self.cat.scan(library_id)
        self.assertEqual(self.cat.paper(paper["id"])["needs_review"], 1)
        self.cat.save_paper(paper["id"], {
            "title": paper["title"], "type": "R", "status": "未读",
            "tags": ["PML-NBs"], "note": "",
        })
        self.assertEqual(self.cat.paper(paper["id"])["needs_review"], 0)

    def test_same_title_different_files_are_only_candidates(self):
        library_id = self.cat.add_library("NB", self.nb)
        self.pdf(self.nb, "[R]A mechanistic classification of clinical phenotypes.pdf", b"one")
        self.pdf(self.nb, "ADRN&MES/[A]A mechanistic classification of clinical phenotypes.pdf", b"two")
        self.cat.scan(library_id)
        groups = self.cat.duplicates()
        self.assertEqual(len(groups), 1)
        self.assertEqual(groups[0]["kind"], "标题相同，文件可能不同")
        self.assertEqual(len(groups[0]["papers"]), 2)

    def test_http_bound_to_local_interface_and_protected_writes(self):
        server = Server(("127.0.0.1", 0), self.cat)
        self.addCleanup(server.server_close)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        self.addCleanup(server.shutdown)
        url = "http://127.0.0.1:" + str(server.server_port)
        with urlopen(url + "/") as response:
            self.assertIn(b"LiteratureShelf", response.read())
        request = Request(url + "/api/libraries", data=json.dumps({
            "name": "NB", "path": str(self.nb)
        }).encode(), headers={"Content-Type": "application/json"}, method="POST")
        with self.assertRaises(HTTPError) as err:
            urlopen(request)
        self.assertEqual(err.exception.code, 400)
        request.add_header("X-Library-Token", server.token)
        with urlopen(request) as response:
            library_id = json.load(response)["id"]
        self.pdf(self.nb, "[B]Genetics and Genomics of Neuroblastoma.pdf")

        def call(route, method="GET", data=None):
            body = json.dumps(data).encode() if data is not None else None
            req = Request(
                url + route, data=body,
                headers={"X-Library-Token": server.token, "Content-Type": "application/json"},
                method=method,
            )
            with urlopen(req) as response:
                return json.load(response)

        self.assertEqual(call(f"/api/libraries/{library_id}/scan", "POST", {})["added"], 1)
        paper = call("/api/papers?q=Genetics")["papers"][0]
        self.assertEqual(paper["type"], "B")
        call(f"/api/papers/{paper['id']}", "PATCH", {
            "title": paper["title"], "type": "B", "status": "粗读",
            "tags": ["起源"], "note": "遗传学背景",
        })
        self.assertEqual(call("/api/papers?q=" + quote("遗传学"))["total"], 1)
        self.assertIn("起源", call(f"/api/papers/{paper['id']}")["tags"])


if __name__ == "__main__":
    unittest.main()
